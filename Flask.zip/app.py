from flask import Flask,render_template,request,redirect,url_for,session
from flask_socketio import SocketIO,join_room,leave_room
from flask_cors import CORS,cross_origin
from flask_pymongo import PyMongo
from bson.objectid import ObjectId
import logging

logging.basicConfig(filename="log.log",format='%(asctime)s :: %(levelname)s :: %(message)s',filemode="w")
logger=logging.getLogger(__name__)

app=Flask(__name__)
socketio=SocketIO(app)

app.secret_key='BAD_SECRET_KEY'

CORS_ORIGINS = ['http://127.0.0.1:5000']
CORS(app, origins=CORS_ORIGINS)

app.config["MONGO_URI"] = "mongodb://localhost:27017/ChatDB"
db = PyMongo(app).db

user_data={}
friend_req=[]


@app.route('/') 
@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    return render_template('login.html')

@app.route('/register',methods=['GET','POST'])
def register():
    return render_template('register.html')

@app.route('/register_check',methods=['GET','POST'])
def register_check():
    global user_data
    if(request.method=='POST'):
        req=request.form
        req=dict(req)
        session['uid'] = req['uid']
        session['password'] = req['password']
        query=db.users.find({'uid':req['uid']})
        flag=0
        for x in query:
            if(x['uid']==req['uid']):
                flag=1
                break
        reg_dict={
            "uid":req['uid'],
            "email":req['email'],
            "password":req['password'],
            "friend_request_from":[],
            "friends":[]
        }
        if(flag==0):
            temp=db.users.insert_one(reg_dict)
            uid=req['uid']
            user_data[uid]={}
            user_data[uid]['cid']=None
            user_data[uid]['user_list']=[]
            user_data[uid]['group_list']=[]
            user_data[uid]['msg_list']={}
            return redirect('/chat/'+str(uid))
        else:
            return render_template('invalid.html',message="User already registered!!")
    return render_template('register.html')

@app.route('/login_check',methods=['GET','POST']) 
def login_check():
    global user_data
    if(request.method=='POST'):
        req=request.form
        session['uid'] = req['uid']
        session['password'] = req['password']
        req=dict(req)
        query=db.users.find({'uid':req['uid']})
        flag=0
        temp=None
        for x in query:
            if(x['uid']==req['uid']):
                flag=1
                temp=x
                break
        if(flag==1):
            if(temp['password']==req['password']):
                uid=req['uid']
                user_data[uid]={}
                user_data[uid]['cid']=None
                user_data[uid]['user_list']=[]
                user_data[uid]['group_list']=[]
                user_data[uid]['msg_list']={}
                return redirect('/chat/'+str(uid))
            else:
                logger.warn('Incorrect password.Username:{} and Password:{}'.format(temp['password'],
                                                                                       temp['uid']))
                return render_template('invalid.html',message='Incorrect Password!!')
        else:
            logger.warn('Unregistered User')
            return render_template('invalid.html',message='User is not registered!!')
    return render_template('login.html')

@app.route('/Friends/<string:user_id>',methods=['GET','POST'])
def Friends(user_id):
    global user_data
    with open("Friends.txt",'r') as file1:
        data=file1.readlines() 
        user_data[user_id]['user_list']=data
    return redirect('/chat/'+str(user_id))
        
@app.route('/Groups/<string:user_id>',methods=['GET','POST'])
def Groups(user_id):
    global user_data
    try:
        file1=open("Groups.txt",'r')
        data=file1.readlines()
        user_data[user_id]['group_list']=data 
        return redirect('/chat/'+str(user_id))
    except:
        return render_template('invalid.html',message='No File found')

@app.route('/update_cid/<string:user_id>/<string:chat_id>',methods=['GET','POST'])
def update_cid(user_id,chat_id):
    global user_data
    user_data[user_id]['cid']=chat_id
    return redirect('/chat/'+str(user_id))

@app.route('/logout',methods=['GET','POST'])
def logout():
    if 'uid' in session:  
        session.clear()
    return redirect(url_for('home'))

@app.route('/chat/<string:user_id>',methods=['GET','POST'])
def chat(user_id):
     global user_data
     if(user_id in user_data):
        return render_template('chat.html',uid=user_id,
                                            cid=user_data[user_id]['cid'],
                                            requests=user_data[user_id]['user_list'],
                                            groups=user_data[user_id]['group_list'],
                                            msg_list=user_data[user_id]['msg_list'])
     return redirect('/home')

@app.route('/friend_check',methods=['GET','POST'])
def friend_check():
    if(request.method=='POST'):
        req=request.form['uid']
        query=db.users.find_one({'uid':req})
        flag=0
        if query:
            flag=1
            fri_req={
            "req":"pending"
            }
        if(flag==1):
            temp=db.users.update_one({'uid':req},
                                    {'$set' :fri_req })
            t=db.users.update_one({'uid':req},
                                    {
                                        '$push':{'friend_request_from':session}
                                    })
            logger.info('request sent')
            logger.info('{} has got friend request'.format(req))
            return redirect(url_for('friend_request',req=req))
        else:
            logger.warn('Unregistered User')
            return render_template('invalid.html',message='User not Registered!!')
    return render_template('chat.html')

@app.route('/friend_request/<req>')
def friend_request(req):

    document =db.users.find_one({"uid": req})
    frnd=document['friend_request_from']
    with open('friend_req.txt','w') as file1:
        for value in frnd:
            file1.write(value['uid'] + '\n')
    file1.close()
    return render_template('chat.html')

@app.route('/access_request/<string:user_id>',methods=['GET','POST'])
def access_request(user_id):
    global user_data
    with open("friend_req.txt",'r') as file1:
        data=file1.readlines() 
        user_data[user_id]['user_list']=data
    query=db.users.find_one({ "uid":user_id,"req": { "$exists": True } })
    if query:
        return redirect('/chat/'+str(user_id))
    else:
        return render_template('invalid.html',message='No friend request')
    
@app.route('/add_friend',methods=['GET','POST'])
def add_friend():
    req=session['uid']
    friend=request.form['friend']
    db.users.update_one({'uid':req},
                        {
                            '$push':{'friends':friend}
                        })
    return redirect(url_for('update_friend_req',user_id=req,friend=friend))

@app.route('/remove_req/<string:user_id>')
def remove_req(user_id):
    return 'd'

@app.route('/update_friend_req/<string:user_id>/<string:friend>')
def update_friend_req(user_id,friend):
    query = {"uid": user_id}
    update = {"$pull": {"friend_request_from": {"uid": friend}}}
    db.users.update_one(query,update)
    return redirect(url_for('friend_request',req=user_id))

@socketio.on('send_message')
def handle_send_message_event(data):
    logger.info("{} has sent message {}".format(data['uid'],data['message']))
    socketio.emit('receive_message', data)

@socketio.on('join_room')
def handle_chat_event(data):
    logger.warn("{} has joined the room".format(data['username']))
    join_room(data['username'])
    socketio.emit('join_room_announcement', data)

@socketio.on('leave_room')
def handle_room_leave_event(data):
    logger.warn("{} has left the room".format(data['username']))
    leave_room(data['room'])
    socketio.emit('leave_room_announcement', data)

if __name__=='__main__':
    socketio.run(app,debug=True)
